package com.yoga.sree.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yoga.sree.model.UserCourse;

public interface UserCourseRepository extends JpaRepository<UserCourse,String> {

}
