package com.yoga.sree;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SreeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SreeApplication.class, args);
	}

}
