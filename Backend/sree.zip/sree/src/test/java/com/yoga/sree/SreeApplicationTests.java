package com.yoga.sree;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SreeApplicationTests {

	@Test
	void contextLoads() {
	}

}
